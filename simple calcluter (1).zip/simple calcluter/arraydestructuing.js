// const student = {
//     name: "Pragadeeshwaran S",
//     age: 23,
//     department: "Information Technology",
//     college: "Knowledge Institute Of Technology"
// }
// let { name, age, department, college, DOB } = student;
// console.log(name); // Pragadeeshwaran S

// student.age = 25;
// console.log(student.age); // 25
// student.DOB = "09-12-2005";
// console.log(student.DOB); // 09-12-2005
// let arr1 = [1, 2, 3];
// let arr2 = [4, 5, 6];
// let arr3 = [...arr1, ...arr2];
// console.log(arr3);
const student = {
    name: "Pragadeeshwaran S",
    age: 23,
    department: "information Technology"
}
const person = {
    name: "tamil selvan G",
    age: 23,
    domain: "Civil"
}
let merge = {...student, ...person, location: "Erode" };
console.log(merge);

function add(a, b, c) {
    return a + b + c;
}
let numbers = [1, 2, 3];
console.log(add(...numbers)); // 6