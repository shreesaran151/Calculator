// Task-1: Higher-order function repeat(func, n)
function repeat(func, n) {
    for (let i = 0; i < n; i++) {
        func();
    }
}
repeat(() => console.log("Task-1: Hello"), 3);


// Task-2: Calculator with callback
function calculator(a, b, callback) {
    return callback(a, b);
}
console.log("Task-2:", calculator(10, 5, (x, y) => x + y)); // add
console.log("Task-2:", calculator(10, 5, (x, y) => x - y)); // subtract
console.log("Task-2:", calculator(10, 5, (x, y) => x * y)); // multiply
console.log("Task-2:", calculator(10, 5, (x, y) => x / y)); // divide


// Task-3: Closure counting function calls
function callCounter() {
    let count = 0;
    return function() {
        count++;
        console.log(`Task-3: Called ${count} times`);
    };
}
const counter = callCounter();
counter();
counter();
counter();


// Task-4: Closure storing secret
function secretKeeper(secret) {
    return function() {
        return `Task-4: The secret is "${secret}"`;
    };
}
const revealSecret = secretKeeper("I love coding!");
console.log(revealSecret());


// Task-5: Anonymous function in setTimeout
setTimeout(() => {
    console.log("Task-5: Printed after 2 seconds");
}, 2000);


// Task-6: var vs let/const scope
if (true) {
    var a = "I leak outside block";
    let b = "I stay inside block";
    const c = "Me too";
}
console.log("Task-6: var =", a);
// console.log(b); // ❌ ReferenceError
// console.log(c); // ❌ ReferenceError


// Task-7: Variable shadowing
let x = 10;
if (true) {
    let x = 20; // shadows outer x
    console.log("Task-7: Inside block =", x);
}
console.log("Task-7: Outside block =", x);


// Task-8: .map() squares
let nums = [1, 2, 3, 4];
let squares = nums.map(n => n * n);
console.log("Task-8:", squares);


// Task-9: .filter() even numbers
let evens = [1, 2, 3, 4, 5, 6].filter(n => n % 2 === 0);
console.log("Task-9:", evens);


// Task-10: .reduce() sum
let sum = [10, 20, 30, 40].reduce((acc, val) => acc + val, 0);
console.log("Task-10:", sum);


// Task-11: .find() first > 10
let found = [5, 12, 8, 130].find(n => n > 10);
console.log("Task-11:", found);


// Task-12: setTimeout() 'Hello'
setTimeout(() => {
    console.log("Task-12: Hello");
}, 2000);


// Task-13: Clear interval after 10 runs
let count = 0;
let intervalId = setInterval(() => {
    console.log(`Task-13: Run ${++count}`);
    if (count === 10) {
        clearInterval(intervalId);
        console.log("Task-13: Interval cleared");
    }
}, 500);


// Task-14: Print current time every second
setInterval(() => {
    let now = new Date();
    console.log("Task-14:", now.toLocaleTimeString());
}, 1000);